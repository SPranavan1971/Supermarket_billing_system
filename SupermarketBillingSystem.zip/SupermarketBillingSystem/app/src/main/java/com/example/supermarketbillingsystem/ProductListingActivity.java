package com.example.supermarketbillingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ProductListingActivity extends AppCompatActivity {

    private RecyclerView recyclerViewProducts;
    private List<Product> productList;
    private List<Product> selectedProducts;
    private ProductAdapter productAdapter;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_listing);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        recyclerViewProducts = findViewById(R.id.recyclerViewProducts);
        recyclerViewProducts.setLayoutManager(new LinearLayoutManager(this));

        // Initialize LinearLayoutManager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerViewProducts.setLayoutManager(layoutManager);


        // Initialize productList with manually added product data
        productList = new ArrayList<>();
        addManualProducts(); // Add products manually

        // Initialize selectedProducts list
        selectedProducts = new ArrayList<>();

        // Initialize productAdapter with the custom ProductAdapter
        productAdapter = new ProductAdapter(this, productList);
        recyclerViewProducts.setAdapter(productAdapter);

        // Handle item click to add product to selectedProducts list
        productAdapter.setOnItemClickListener(new ProductAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Product product) {
                // Toggle selection
                if (selectedProducts.contains(product)) {
                    selectedProducts.remove(product);
                } else {
                    selectedProducts.add(product);
                }
            }
        });

        // Handle "View Cart" button click
        Button viewCartButton = findViewById(R.id.viewCartButton);
        viewCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Move to the ProductDetailsActivity and pass the list of selected products
                Intent intent = new Intent(ProductListingActivity.this, ProductDetailsActivity.class);
                intent.putParcelableArrayListExtra("selectedProducts", new ArrayList<>(selectedProducts));
                startActivity(intent);
            }
        });
    }

    private void addManualProducts() {
        productList.add(new Product(1, "Apple", 150.00));
        productList.add(new Product(2, "Banana", 35.00));
        productList.add(new Product(3, "Orange", 85.00));
        productList.add(new Product(4, "Grapes", 180.00));
        productList.add(new Product(5, "Straw Berries", 300.00));
        productList.add(new Product(6, "Watermelon", 125.00));
        productList.add(new Product(7, "Pineapple", 160.00));
        productList.add(new Product(8, "Lemon", 40.00));
        productList.add(new Product(9, "Mango", 55.00));
        productList.add(new Product(10, "Potato", 180.00));
        productList.add(new Product(11, "Onion", 200.00));
        productList.add(new Product(12, "Carrot", 120.00));
        productList.add(new Product(13, "Tomato", 55.00));
        productList.add(new Product(14, "Pepper", 50.00));
        productList.add(new Product(15, "Cucumber", 90.00));
        productList.add(new Product(16, "Mushrooms", 170.00));
        productList.add(new Product(17, "Bread", 145.00));
        productList.add(new Product(18, "Bagels", 100.00));
        productList.add(new Product(19, "Dinner Rolls", 80.00));
        productList.add(new Product(20, "Croissants", 80.00));
        productList.add(new Product(21, "Chocolate Chip Cookies", 100.00));
        productList.add(new Product(22, "Donuts", 150.00));
        productList.add(new Product(23, "Beef Steak", 100.00));
        productList.add(new Product(24, "Chicken", 1500.00));
        productList.add(new Product(25, "Pork", 1800.00));
        productList.add(new Product(26, "Fish", 350.00));
        productList.add(new Product(27, "Mutton", 1900.00));
        productList.add(new Product(28, "Cheese", 350.00));
        productList.add(new Product(29, "Prepared Salad", 150.00));
        productList.add(new Product(30, "Cow's Milk (Whole)", 240.00));
        productList.add(new Product(31, "Almond Milk (Unsweetened)", 180.00));
        productList.add(new Product(32, "Oat Milk", 280.00));
        productList.add(new Product(33, "Swiss Cheese", 680.00));
        productList.add(new Product(34, "Cream Cheese", 350.00));
        productList.add(new Product(35, "Plain Yogurt", 75.00));
        productList.add(new Product(36, "Flavored Yogurt", 120.00));
        productList.add(new Product(37, "Salted Butter", 280.00));
        productList.add(new Product(38, "Unsalted Butter", 240.00));
        productList.add(new Product(39, "Eggs (Dozen)", 660.00));
        productList.add(new Product(40, "Rice", 180.00));
        productList.add(new Product(41, "Pasta (Spaghetti)", 90.00));
        productList.add(new Product(42, "Canned Fish", 380.00));
        productList.add(new Product(43, "Hot Sauce", 540.00));
        productList.add(new Product(44, "Soy Sauce", 480.00));
        productList.add(new Product(45, "Brown Sugar", 280.00));
        productList.add(new Product(46, "Flour", 170.00));
        productList.add(new Product(47, "White Sugar", 270.00));
        productList.add(new Product(48, "Pepper Powder", 100.00));
        productList.add(new Product(49, "Olive Oil", 1100.00));
        productList.add(new Product(50, "Vegetable Oil", 1400.00));
        productList.add(new Product(51, "Apple Cider Vinegar", 700.00));
        productList.add(new Product(52, "Potato Chips (Original)", 280.00));
        productList.add(new Product(53, "Microwave Popcorn", 180.00));
        productList.add(new Product(54, "Saltine Crackers", 120.00));
        productList.add(new Product(55, "Chocolate Chip Cookies", 180.00));
        productList.add(new Product(56, "Peanut Butter Cookies", 300.00));
        productList.add(new Product(57, "Oatmeal Raisin Cookies", 250.00));
        productList.add(new Product(58, "Chocolate Bars (Milk Chocolate)", 240.00));
        productList.add(new Product(59, "Gummy Bears", 100.00));
        productList.add(new Product(60, "Hard Candy", 20.00));
        productList.add(new Product(61, "Almonds", 270.00));
        productList.add(new Product(62, "Peanuts (in Shell)", 100.00));
        productList.add(new Product(63, "Cashews", 1500.00));
        productList.add(new Product(64, "Sunflower Seeds (Salted)", 150.00));
        productList.add(new Product(65, "Pumpkin Seeds (Roasted)", 40.00));
        productList.add(new Product(66, "Frozen Corn", 70.00));
        productList.add(new Product(67, "Cheese Pizza", 800.00));
        productList.add(new Product(68, "Beef Burritos", 400.00));
        productList.add(new Product(69, "Chicken Nuggets (Frozen)", 500.00));
        productList.add(new Product(70, "Fish Sticks (Frozen)", 200.00));
        productList.add(new Product(71, "Ground Beef Patties (Frozen)", 480.00));
        productList.add(new Product(72, "Vanilla Ice Cream (Frozen)", 120.00));
        productList.add(new Product(73, "Chocolate Ice Cream (Frozen)", 130.00));
        productList.add(new Product(74, "Strawberry Ice Cream (Frozen)", 160.00));
        productList.add(new Product(75, "Coffee Ice Cream (Frozen)", 120.00));
        productList.add(new Product(76, "Cookies and Cream Ice Cream (Frozen)", 180.00));
        productList.add(new Product(77, "Butter Pecan Ice Cream (Frozen)", 150.00));
        productList.add(new Product(78, "Coca-Cola", 340.00));
        productList.add(new Product(79, "Sprite", 270.00));
        productList.add(new Product(80, "Fanta Orange", 270.00));
        productList.add(new Product(81, "Mountain Dew", 280.00));
        productList.add(new Product(82, "Ginger Beer", 260.00));
        productList.add(new Product(83, "Pepsi", 280.00));
        productList.add(new Product(84, "Orange Juice", 150.00));
        productList.add(new Product(85, "Apple Juice", 150.00));
        productList.add(new Product(86, "Pineapple Juice", 150.00));
        productList.add(new Product(87, "Mango Juice", 150.00));
        productList.add(new Product(88, "Avocado Juice", 150.00));
        productList.add(new Product(89, "Lemon Juice", 100.00));
        productList.add(new Product(90, "Coconut Water", 100.00));
        productList.add(new Product(91, "Purified Water", 120.00));
        productList.add(new Product(92, "Red Bull", 900.00));
        productList.add(new Product(93, "Monster Energy", 750.00));
        productList.add(new Product(94, "Ride", 350.00));
        productList.add(new Product(95, "Coffee Bean", 300.00));
        productList.add(new Product(96, "Coffee powder", 250.00));
        productList.add(new Product(97, "Black Tea", 20.00));
        productList.add(new Product(98, "Nescafe", 100.00));
        productList.add(new Product(99, "Green Tea (Sencha)", 100.00));
        productList.add(new Product(100, "Herbal Tea (Chamomile)", 150.00));
        productList.add(new Product(101, "Head & Shoulders", 380.00));
        productList.add(new Product(102, "Pantene Pro V", 380.00));
        productList.add(new Product(103, "Meera Shampoo", 370.00));
        productList.add(new Product(104, "Dove Shampoo", 350.00));
        productList.add(new Product(105, "Irish Spring Body wash", 370.00));
        productList.add(new Product(106, "Dove Body wash", 290.00));
        productList.add(new Product(107, "Talcum powder", 280.00));
        productList.add(new Product(108, "Fair & Lovely face cream", 380.00));
        productList.add(new Product(109, "Baby cheramy", 140.00));
        productList.add(new Product(110, "Lifebuoy", 160.00));
        productList.add(new Product(111, "Pears", 145.00));
        productList.add(new Product(112, "Dettol", 180.00));
        productList.add(new Product(113, "Sunlight", 135.00));
        productList.add(new Product(114, "Dove soap", 240.00));
        productList.add(new Product(115, "Fogg body spray", 1480.00));
        productList.add(new Product(116, "Nivea body spray for women", 1690.00));
        productList.add(new Product(117, "Old Spice deodorant", 1880.00));
        productList.add(new Product(118, "Secret deodorant", 1460.00));
        productList.add(new Product(119, "Clogard", 185.00));
        productList.add(new Product(120, "Colgate", 220.00));
        productList.add(new Product(121, "Gillette Mach3 shaving razor", 2800.00));
        productList.add(new Product(122, "Nivea men after shave", 2600.00));
        productList.add(new Product(123, "Signal brush", 180.00));
        productList.add(new Product(124, "Surfexcel", 480.00));
        productList.add(new Product(125, "sunlight Powder", 390.00));
        productList.add(new Product(126, "Vim", 145.00));
        productList.add(new Product(127, "All-Purpose Cleaner", 290.00));
        productList.add(new Product(128, "Glass Cleaner", 250.00));
        productList.add(new Product(129, "Harpic", 680.00));
        productList.add(new Product(130, "Disinfecting Wipes", 200.00));
        productList.add(new Product(131, "Sponges", 150.00));
        productList.add(new Product(132, "Microfiber Cloths", 250.00));
        productList.add(new Product(133, "Light Bulbs (LED)", 220.00));
        productList.add(new Product(134, "AA Batteries", 100.00));
        productList.add(new Product(135, "AAA Batteries", 140.00));
        productList.add(new Product(136, "Fire Extinguisher", 3800.00));
        productList.add(new Product(137, "Smoke Detectors", 1400.00));
        productList.add(new Product(138, "Air Freshener", 250.00));
        productList.add(new Product(139, "Dishwashing Gloves", 200.00));
        productList.add(new Product(140, "Cutting Boards", 680.00));


    }
}
