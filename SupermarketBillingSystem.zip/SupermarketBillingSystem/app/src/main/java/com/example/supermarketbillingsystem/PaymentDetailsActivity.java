package com.example.supermarketbillingsystem;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PaymentDetailsActivity extends AppCompatActivity {

    private TextView textViewName, textViewPhone, textViewTotalAmount;
    private EditText editTextAmountReceived;

    private String name, phone, nic, address;
    private double totalAmount;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_details);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        textViewName = findViewById(R.id.textViewName);
        textViewPhone = findViewById(R.id.textViewPhone);
        textViewTotalAmount = findViewById(R.id.textViewTotalAmount);
        editTextAmountReceived = findViewById(R.id.editTextAmountReceived);

        // Get customer details and total amount from intent
        Intent intent = getIntent();
        if (intent != null) {
            name = intent.getStringExtra("name");
            phone = intent.getStringExtra("phone");
            nic = intent.getStringExtra("nic");
            address = intent.getStringExtra("address");
            totalAmount = intent.getDoubleExtra("totalAmount", 0.0);
        }

        // Set customer details and total amount
        textViewName.setText("Name: " + name);
        textViewPhone.setText("Phone: " + phone);
        textViewTotalAmount.setText("Total Amount: Rs:" + totalAmount);

        // Handle "Pay" button click
        Button buttonPay = findViewById(R.id.buttonPay);
        buttonPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amountReceivedStr = editTextAmountReceived.getText().toString().trim();
                if (amountReceivedStr.isEmpty()) {
                    Toast.makeText(PaymentDetailsActivity.this, "Please enter amount received", Toast.LENGTH_SHORT).show();
                } else {
                    double amountReceived = Double.parseDouble(amountReceivedStr);
                    double balanceAmount = amountReceived - totalAmount;

                    // Check if the customer already exists in the database
                    long customerId = dbHelper.getCustomerId(name, phone);
                    if (customerId == -1) {
                        // If the customer doesn't exist, insert the customer into the database
                        customerId = dbHelper.addCustomer(new Customer(name, phone, nic, address));
                        if (customerId == -1) {
                            Toast.makeText(PaymentDetailsActivity.this, "Failed to add customer", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }

                    // Insert payment details into the database using the existing or newly generated customer ID
                    long paymentId = dbHelper.addPayment(new Payment((int) customerId, totalAmount, amountReceived));
                    if (paymentId != -1) {
                        // Calculate balance amount
                        double balance = balanceAmount;

                        // Insert balance details into the database
                        long balanceId = dbHelper.addBalance(new Balance((int) customerId, totalAmount, amountReceived, balance));
                        if (balanceId != -1) {
                            String message = "Payment completed.\nBalance amount: Rs:" + balanceAmount + "\nThank you! Come again.";
                            Toast.makeText(PaymentDetailsActivity.this, message, Toast.LENGTH_LONG).show();

                            Intent thankYouIntent = new Intent(PaymentDetailsActivity.this, ThankYouActivity.class);
                            thankYouIntent.putExtra("customerId", customerId);
                            thankYouIntent.putExtra("paymentId", paymentId);
                            thankYouIntent.putExtra("balanceId", balanceId);
                            thankYouIntent.putExtra("totalAmount", totalAmount);
                            thankYouIntent.putExtra("amountReceived", amountReceived);
                            thankYouIntent.putExtra("name", name);
                            thankYouIntent.putExtra("phone", phone);
                            startActivity(thankYouIntent);
                            finish();
                        } else {
                            Toast.makeText(PaymentDetailsActivity.this, "Failed to add balance", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(PaymentDetailsActivity.this, "Failed to add payment", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

}

