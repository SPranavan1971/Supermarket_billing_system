package com.example.supermarketbillingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    private ListView listViewCart;
    private List<Product> cartItems;
    private ArrayAdapter<String> cartAdapter; // Change ArrayAdapter type to String
    private TextView totalPriceTextView;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        listViewCart = findViewById(R.id.listViewCart);
        totalPriceTextView = findViewById(R.id.totalPriceTextView);

        // Get cart items from intent
        cartItems = getIntent().getParcelableArrayListExtra("selectedProducts");

        // Initialize cartAdapter with an empty list and set it to listViewCart
        cartAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        listViewCart.setAdapter(cartAdapter);

        // Display cart items and calculate total amount
        displayCartItems();

        // Handle "Customer Details" button click
        Button buttonCustomerDetails = findViewById(R.id.buttonCustomerDetails);
        buttonCustomerDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add cart items to the database
                addCartItemsToDatabase();

                // Pass total amount to CustomerDetailsActivity
                Intent intent = new Intent(CartActivity.this, CustomerDetailsActivity.class);
                intent.putExtra("totalAmount", calculateTotalPrice()); // Pass total amount here
                startActivity(intent);
            }
        });
    }

    // Method to calculate total price
    private double calculateTotalPrice() {
        double totalPrice = 0;
        for (Product product : cartItems) {
            totalPrice += product.getPrice();
        }
        return totalPrice;
    }

    private void displayCartItems() {
        double totalPrice = 0;
        List<String> cartItemStrings = new ArrayList<>();
        for (Product product : cartItems) {
            // Create a string representation for each cart item (ID: Name - Price)
            String cartItemString = "ID: " + product.getId() + " - " + product.getName() + " - Rs:" + product.getPrice();
            cartItemStrings.add(cartItemString);
            totalPrice += product.getPrice();
        }
        // Update the adapter with the list of cart item strings
        cartAdapter.clear();
        cartAdapter.addAll(cartItemStrings);

        // Update total price text view
        totalPriceTextView.setText("Total: Rs:" + totalPrice);
    }

    // Method to add cart items to the database
    private void addCartItemsToDatabase() {
        for (Product product : cartItems) {
            long rowId = dbHelper.addCartItem(new CartItem(product.getId(), product.getName(), product.getPrice(), product.getPrice()));
            // You can handle the rowId if necessary
        }
    }
}
