package com.example.supermarketbillingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CustomerDetailsActivity extends AppCompatActivity {

    private EditText editTextName, editTextPhone, editTextNIC, editTextAddress;

    private double totalAmount; // Add a variable to store the total amount

    private DataRepository dataRepository; // Change the reference to DataRepository

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_details);

        dataRepository = new DataRepository(this); // Initialize DataRepository

        // Initialize views
        editTextName = findViewById(R.id.editTextName);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextNIC = findViewById(R.id.editTextNIC);
        editTextAddress = findViewById(R.id.editTextAddress);

        // Get total amount from intent
        totalAmount = getIntent().getDoubleExtra("totalAmount", 0.0); // Get the total amount

        // Handle "Make Payment" button click
        Button buttonMakePayment = findViewById(R.id.buttonMakePayment);
        buttonMakePayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get customer details from EditText fields
                String name = editTextName.getText().toString().trim();
                String phone = editTextPhone.getText().toString().trim();
                String nic = editTextNIC.getText().toString().trim();
                String address = editTextAddress.getText().toString().trim();

                // Validate customer details
                if (name.isEmpty() || phone.isEmpty() || nic.isEmpty() || address.isEmpty()) {
                    Toast.makeText(CustomerDetailsActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Check if the customer already exists in the database
                    long customerId = dataRepository.getCustomerId(name, phone);
                    if (customerId == -1) {
                        // If the customer doesn't exist, insert the customer into the database
                        Customer customer = new Customer(name, phone, nic, address);
                        customerId = dataRepository.addCustomer(customer);
                        if (customerId == -1) {
                            Toast.makeText(CustomerDetailsActivity.this, "Failed to add customer", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }

                    // Proceed to PaymentDetailsActivity
                    Intent intent = new Intent(CustomerDetailsActivity.this, PaymentDetailsActivity.class);
                    intent.putExtra("customerId", customerId); // Pass the customerId to PaymentDetailsActivity
                    intent.putExtra("name", name); // Pass name to PaymentDetailsActivity
                    intent.putExtra("phone", phone); // Pass phone to PaymentDetailsActivity
                    intent.putExtra("totalAmount", totalAmount); // Pass the total amount to PaymentDetailsActivity
                    startActivity(intent);
                }
            }
        });
    }

}
