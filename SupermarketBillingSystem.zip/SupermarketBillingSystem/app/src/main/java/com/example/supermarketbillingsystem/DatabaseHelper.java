package com.example.supermarketbillingsystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "supermarket.db";

    private DatabaseHelper dbHelper;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    SQLiteDatabase db = this.getWritableDatabase(); //



    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Product.CREATE_TABLE);
        db.execSQL(CartItem.CREATE_TABLE);
        db.execSQL(Customer.CREATE_TABLE);
        db.execSQL(Payment.CREATE_TABLE);
        db.execSQL(Balance.CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Product.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + CartItem.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Customer.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Payment.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Balance.TABLE_NAME);
        onCreate(db);
    }



    private static final String TABLE_CUSTOMERS = "customers";
    private static final String TABLE_PAYMENTS = "payments";

    // Common column names
    private static final String COLUMN_ID = "id";

    // Customers table column names
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_PHONE = "phone";
    private static final String COLUMN_NIC = "nic";
    private static final String COLUMN_ADDRESS = "address";

    // Payments table column names
    private static final String COLUMN_CUSTOMER_ID = "customer_id";
    private static final String COLUMN_TOTAL_AMOUNT = "total_amount";
    private static final String COLUMN_AMOUNT_RECEIVED = "amount_received";

    // Table create statements
    private static final String CREATE_TABLE_CUSTOMERS = "CREATE TABLE " + TABLE_CUSTOMERS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NAME + " TEXT,"
            + COLUMN_PHONE + " TEXT,"
            + COLUMN_NIC + " TEXT,"
            + COLUMN_ADDRESS + " TEXT"
            + ")";

    private static final String CREATE_TABLE_PAYMENTS = "CREATE TABLE " + TABLE_PAYMENTS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_CUSTOMER_ID + " INTEGER,"
            + COLUMN_TOTAL_AMOUNT + " REAL,"
            + COLUMN_AMOUNT_RECEIVED + " REAL"
            + ")";




    // Add a customer to the database
    public long addCustomer(Customer customer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, customer.getName());
        values.put(COLUMN_PHONE, customer.getPhone());
        values.put(COLUMN_NIC, customer.getNic());
        values.put(COLUMN_ADDRESS, customer.getAddress());
        // Insert row
        long id = db.insert(TABLE_CUSTOMERS, null, values);
        // Close database connection
        db.close();
        return id;
    }

    // Add a payment to the database
    public long addPayment(Payment payment) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CUSTOMER_ID, payment.getCustomerId());
        values.put(COLUMN_TOTAL_AMOUNT, payment.getTotalAmount());
        values.put(COLUMN_AMOUNT_RECEIVED, payment.getAmountReceived());
        // Insert row
        long id = db.insert(TABLE_PAYMENTS, null, values);
        // Close database connection
        db.close();
        return id;
    }


        // Method to get customer ID by name and phone
        public long getCustomerId(String name, String phone) {
            SQLiteDatabase db = this.getReadableDatabase();
            long customerId = -1;

            String[] projection = {Customer.COLUMN_ID};
            String selection = Customer.COLUMN_NAME + " = ? AND " + Customer.COLUMN_PHONE + " = ?";
            String[] selectionArgs = {name, phone};

            Cursor cursor = db.query(
                    Customer.TABLE_NAME,     // The table to query
                    projection,              // The array of columns to return (null to return all)
                    selection,               // The columns for the WHERE clause
                    selectionArgs,           // The values for the WHERE clause
                    null,                    // don't group the rows
                    null,                    // don't filter by row groups
                    null                     // don't sort
            );

            if (cursor != null && cursor.moveToFirst()) {
                customerId = cursor.getLong(cursor.getColumnIndexOrThrow(Customer.COLUMN_ID));
                cursor.close();
            }

            return customerId;
        }

    public long addBalance(Balance balance) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Balance.COLUMN_CUSTOMER_ID, balance.getCustomerId());
        values.put(Balance.COLUMN_TOTAL_AMOUNT, balance.getTotalAmount());
        values.put(Balance.COLUMN_AMOUNT_RECEIVED, balance.getAmountReceived());
        values.put(Balance.COLUMN_BALANCE, balance.getBalance());
        long id = db.insert(Balance.TABLE_NAME, null, values);
        db.close();
        return id;
    }

    public long addCartItem(CartItem cartItem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CartItem.COLUMN_PRODUCT_ID, cartItem.getProductId());
        values.put(CartItem.COLUMN_NAME, cartItem.getName());
        values.put(CartItem.COLUMN_PRICE, cartItem.getPrice());
        values.put(CartItem.COLUMN_TOTAL_PRICE, cartItem.getTotalPrice());
        long id = db.insert(CartItem.TABLE_NAME, null, values);
        db.close();
        return id;
    }

    public long addProduct(Product product) {
        SQLiteDatabase db = this.getWritableDatabase();
        long id;

        // Check if the product with the same name already exists
        Cursor cursor = db.rawQuery("SELECT " + Product.COLUMN_ID + " FROM " + Product.TABLE_NAME +
                " WHERE " + Product.COLUMN_NAME + " = ?", new String[]{product.getName()});

        if (cursor != null && cursor.moveToFirst()) {
            // Product with the same name already exists, update the existing product
            id = cursor.getLong(0);
            cursor.close();

            ContentValues values = new ContentValues();
            values.put(Product.COLUMN_PRICE, product.getPrice());

            // Update the existing product with the new price
            db.update(Product.TABLE_NAME, values, Product.COLUMN_ID + " = ?",
                    new String[]{String.valueOf(id)});
        } else {
            // Product with the same name does not exist, insert the new product
            ContentValues values = new ContentValues();
            values.put(Product.COLUMN_NAME, product.getName());
            values.put(Product.COLUMN_PRICE, product.getPrice());
            id = db.insert(Product.TABLE_NAME, null, values);
        }

        db.close();
        return id;
    }


}


