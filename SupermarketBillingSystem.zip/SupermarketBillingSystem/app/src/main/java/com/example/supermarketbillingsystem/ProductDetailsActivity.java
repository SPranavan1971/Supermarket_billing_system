package com.example.supermarketbillingsystem;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.ArrayList;
import java.util.List;

public class ProductDetailsActivity extends AppCompatActivity {

    private LinearLayout productDetailsLayout;
    private Button addToCartButton;
    private List<Product> selectedProducts;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        productDetailsLayout = findViewById(R.id.productDetailsLayout);
        addToCartButton = findViewById(R.id.addToCartButton);

        // Initialize LinearLayoutManager
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
//        recyclerViewProducts.setLayoutManager(layoutManager);


        // Get the selected products from the intent
        selectedProducts = getIntent().getParcelableArrayListExtra("selectedProducts");

        // Display selected products
        if (selectedProducts != null) {
            displaySelectedProducts(selectedProducts);
        }

        // Handle "Add to Cart" button click
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pass selected products to CartActivity
                Intent intent = new Intent(ProductDetailsActivity.this, CartActivity.class);
                intent.putParcelableArrayListExtra("selectedProducts", new ArrayList<>(selectedProducts));
                startActivity(intent);

                // Navigate back to ProductListingActivity
                finish();
            }
        });
    }

    private void displaySelectedProducts(List<Product> products) {
        for (Product product : products) {
            TextView productNameTextView = new TextView(this);
            productNameTextView.setText("Product: " + product.getName());

            TextView productPriceTextView = new TextView(this);
            productPriceTextView.setText("Price: Rs:" + product.getPrice());

            productDetailsLayout.addView(productNameTextView);
            productDetailsLayout.addView(productPriceTextView);
        }
    }
}
