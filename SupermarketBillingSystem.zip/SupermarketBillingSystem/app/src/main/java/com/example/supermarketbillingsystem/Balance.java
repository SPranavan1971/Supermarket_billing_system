package com.example.supermarketbillingsystem;

public class Balance {
    private int id;
    private int customerId;
    private double totalAmount;
    private double amountReceived;
    private double balance;

    public static final String TABLE_NAME = "balances";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_CUSTOMER_ID = "customer_id";
    public static final String COLUMN_TOTAL_AMOUNT = "total_amount";
    public static final String COLUMN_AMOUNT_RECEIVED = "amount_received";
    public static final String COLUMN_BALANCE = "balance";

    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_CUSTOMER_ID + " INTEGER,"
                    + COLUMN_TOTAL_AMOUNT + " REAL,"
                    + COLUMN_AMOUNT_RECEIVED + " REAL,"
                    + COLUMN_BALANCE + " REAL"
                    + ")";

    // Constructors, getters, and setters
    public Balance() {}

    public Balance(int customerId, double totalAmount, double amountReceived, double balance) {
        this.customerId = customerId;
        this.totalAmount = totalAmount;
        this.amountReceived = amountReceived;
        this.balance = balance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getAmountReceived() {
        return amountReceived;
    }

    public void setAmountReceived(double amountReceived) {
        this.amountReceived = amountReceived;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}

