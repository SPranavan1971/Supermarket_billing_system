package com.example.supermarketbillingsystem;


import android.os.Parcel;
import android.os.Parcelable;

public class CartItem {
    private int id;
    private int productId;
    private String name;
    private double price;
    private double totalPrice;

    public static final String TABLE_NAME = "cart";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_PRODUCT_ID = "product_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_TOTAL_PRICE = "total_price";

    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_PRODUCT_ID + " INTEGER,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_PRICE + " REAL,"
                    + COLUMN_TOTAL_PRICE + " REAL"
                    + ")";

    // Constructors, getters, and setters
    public CartItem() {}

    public CartItem(int productId, String name, double price, double totalPrice) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.totalPrice = totalPrice;
    }

    protected CartItem(Parcel in) {
        id = in.readInt();
        productId = in.readInt();
        name = in.readString();
        price = in.readDouble();
        totalPrice = in.readDouble();
    }

    public static final Parcelable.Creator<CartItem> CREATOR = new Parcelable.Creator<CartItem>() {
        @Override
        public CartItem createFromParcel(Parcel in) {
            return new CartItem(in);
        }

        @Override
        public CartItem[] newArray(int size) {
            return new CartItem[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}

