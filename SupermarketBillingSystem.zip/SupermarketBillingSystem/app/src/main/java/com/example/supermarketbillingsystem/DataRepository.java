package com.example.supermarketbillingsystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DataRepository {
    private SQLiteDatabase db;

    public DataRepository(Context context) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long addProduct(Product product) {
        ContentValues values = new ContentValues();
        values.put(Product.COLUMN_NAME, product.getName());
        values.put(Product.COLUMN_PRICE, product.getPrice());
        return db.insert(Product.TABLE_NAME, null, values);
    }

    public long addCustomer(Customer customer) {
        ContentValues values = new ContentValues();
        values.put(Customer.COLUMN_NAME, customer.getName());
        values.put(Customer.COLUMN_PHONE, customer.getPhone());
        values.put(Customer.COLUMN_NIC, customer.getNic());
        values.put(Customer.COLUMN_ADDRESS, customer.getAddress());
        return db.insert(Customer.TABLE_NAME, null, values);
    }

    public long addPayment(Payment payment) {
        ContentValues values = new ContentValues();
        values.put(Payment.COLUMN_CUSTOMER_ID, payment.getCustomerId());
        values.put(Payment.COLUMN_TOTAL_AMOUNT, payment.getTotalAmount());
        values.put(Payment.COLUMN_AMOUNT_RECEIVED, payment.getAmountReceived());
        return db.insert(Payment.TABLE_NAME, null, values);
    }

    public long addCartItem(CartItem cartItem) {
        ContentValues values = new ContentValues();
        values.put(CartItem.COLUMN_PRODUCT_ID, cartItem.getProductId());
        values.put(CartItem.COLUMN_NAME, cartItem.getName());
        values.put(CartItem.COLUMN_PRICE, cartItem.getPrice());
        values.put(CartItem.COLUMN_TOTAL_PRICE, cartItem.getTotalPrice());
        return db.insert(CartItem.TABLE_NAME, null, values);
    }

    public int updateProduct(Product product) {
        ContentValues values = new ContentValues();
        values.put(Product.COLUMN_NAME, product.getName());
        values.put(Product.COLUMN_PRICE, product.getPrice());
        return db.update(Product.TABLE_NAME, values, Product.COLUMN_ID + " = ?",
                new String[]{String.valueOf(product.getId())});
    }

    public int updateCustomer(Customer customer) {
        ContentValues values = new ContentValues();
        values.put(Customer.COLUMN_NAME, customer.getName());
        values.put(Customer.COLUMN_PHONE, customer.getPhone());
        values.put(Customer.COLUMN_NIC, customer.getNic());
        values.put(Customer.COLUMN_ADDRESS, customer.getAddress());
        return db.update(Customer.TABLE_NAME, values, Customer.COLUMN_ID + " = ?",
                new String[]{String.valueOf(customer.getId())});
    }

    public int updatePayment(Payment payment) {
        ContentValues values = new ContentValues();
        values.put(Payment.COLUMN_CUSTOMER_ID, payment.getCustomerId());
        values.put(Payment.COLUMN_TOTAL_AMOUNT, payment.getTotalAmount());
        values.put(Payment.COLUMN_AMOUNT_RECEIVED, payment.getAmountReceived());
        return db.update(Payment.TABLE_NAME, values, Payment.COLUMN_ID + " = ?",
                new String[]{String.valueOf(payment.getId())});
    }

    public int updateCartItem(CartItem cartItem) {
        ContentValues values = new ContentValues();
        values.put(CartItem.COLUMN_PRODUCT_ID, cartItem.getProductId());
        values.put(CartItem.COLUMN_NAME, cartItem.getName());
        values.put(CartItem.COLUMN_PRICE, cartItem.getPrice());
        values.put(CartItem.COLUMN_TOTAL_PRICE, cartItem.getTotalPrice());
        return db.update(CartItem.TABLE_NAME, values, CartItem.COLUMN_ID + " = ?",
                new String[]{String.valueOf(cartItem.getId())});
    }

    public int deleteProduct(int productId) {
        return db.delete(Product.TABLE_NAME, Product.COLUMN_ID + " = ?",
                new String[]{String.valueOf(productId)});
    }

    public int deleteCustomer(int customerId) {
        return db.delete(Customer.TABLE_NAME, Customer.COLUMN_ID + " = ?",
                new String[]{String.valueOf(customerId)});
    }

    public int deletePayment(int paymentId) {
        return db.delete(Payment.TABLE_NAME, Payment.COLUMN_ID + " = ?",
                new String[]{String.valueOf(paymentId)});
    }

    public int deleteCartItem(int cartItemId) {
        return db.delete(CartItem.TABLE_NAME, CartItem.COLUMN_ID + " = ?",
                new String[]{String.valueOf(cartItemId)});
    }

    public long getCustomerId(String name, String phone) {
        long customerId = -1;
        String[] columns = {Customer.COLUMN_ID};
        String selection = Customer.COLUMN_NAME + " = ? AND " + Customer.COLUMN_PHONE + " = ?";
        String[] selectionArgs = {name, phone};
        Cursor cursor = db.query(Customer.TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(Customer.COLUMN_ID);
            if (columnIndex != -1) {
                customerId = cursor.getLong(columnIndex);
            }
        }
        cursor.close();
        return customerId;
    }






    // Implement methods for querying data
    // These methods will return Cursor or List objects containing queried data
    // Example: public Cursor getAllProducts() { /* Implement query logic here */ }
}

