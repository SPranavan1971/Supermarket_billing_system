package com.example.supermarketbillingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ThankYouActivity extends AppCompatActivity {

    private TextView textViewBalanceReceived, textViewTotalAmount, textViewAmountReceived, textViewName, textViewPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_you);

        textViewBalanceReceived = findViewById(R.id.textViewBalanceReceived);
        textViewTotalAmount = findViewById(R.id.textViewTotalAmount);
        textViewAmountReceived = findViewById(R.id.textViewAmountReceived);
        textViewName = findViewById(R.id.textViewName);
        textViewPhone = findViewById(R.id.textViewPhone);

        // Get values from intent
        double totalAmount = getIntent().getDoubleExtra("totalAmount", 0.0);
        double amountReceived = getIntent().getDoubleExtra("amountReceived", 0.0);
        String name = getIntent().getStringExtra("name");
        String phone = getIntent().getStringExtra("phone");

        // Calculate balance
        double balanceReceived = amountReceived - totalAmount;

        // Display values
        textViewBalanceReceived.setText("Customer's Balance: Rs:" + balanceReceived);
        textViewTotalAmount.setText("Total Amount: Rs:" + totalAmount);
        textViewAmountReceived.setText("Amount Received: Rs:" + amountReceived);
        textViewName.setText("Name: " + name);
        textViewPhone.setText("Phone: " + phone);

        // Handle "Back to Main Activity" button click
        Button buttonBackToMain = findViewById(R.id.buttonBackToMain);
        buttonBackToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the main activity
                Intent intent = new Intent(ThankYouActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish(); // Finish the current activity to prevent going back to it with back button
            }
        });
    }
}
