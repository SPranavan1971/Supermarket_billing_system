package com.example.supermarketbillingsystem;


public class Payment {
    private int id;
    private int customerId;
    private double totalAmount;
    private double amountReceived;

    public static final String TABLE_NAME = "payments";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_CUSTOMER_ID = "customer_id";
    public static final String COLUMN_TOTAL_AMOUNT = "total_amount";
    public static final String COLUMN_AMOUNT_RECEIVED = "amount_received";

    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_CUSTOMER_ID + " INTEGER,"
                    + COLUMN_TOTAL_AMOUNT + " REAL,"
                    + COLUMN_AMOUNT_RECEIVED + " REAL"
                    + ")";

    // Constructors, getters, and setters
    public Payment() {}

    public Payment(int customerId, double totalAmount, double amountReceived) {
        this.customerId = customerId;
        this.totalAmount = totalAmount;
        this.amountReceived = amountReceived;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getAmountReceived() {
        return amountReceived;
    }

    public void setAmountReceived(double amountReceived) {
        this.amountReceived = amountReceived;
    }
}


